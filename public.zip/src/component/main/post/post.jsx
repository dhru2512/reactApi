import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";



function Post() {

  const postData = [
    { id: 1, title: 'Post Title 1', country: 'India', content: 'Welcome to learning React!', date: 'Nov 12' },
    { id: 2, title: 'Post Title 2', country: 'World', content: 'You can install React from npm.', date: 'Nov 11' },
    { id: 3, title: 'Post Title 3', country: 'USA', content: 'Welcome to learning React!', date: 'Dec 25' },
    { id: 4, title: 'Post Title 4', country: 'India', content: 'You can install React from npm.', date: 'Feb 12' }
  ]

  const [hasError, setErrors] = useState(false);
  const [planets, setPlanets] = useState({});

  async function fetchData() {
    const res = await fetch("https://swapi.dev/api/planets/1/");
    res
      .json()
      .then((res) => setPlanets(res))
      .catch((err) => setErrors(err));
  }

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="row mb-2">

<div>
      <span>{JSON.stringify(planets)}</span>
      <hr />
      <span>Has error: {JSON.stringify(hasError)}</span>
    </div>


    
     {postData.map((postData) =>
         <div className="col-md-6" key={postData.id}>
         <div className="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
           <div className="col p-4 d-flex flex-column position-static">
             <strong className="d-inline-block mb-2 text-primary">{postData.country}</strong>
             <h3 className="mb-0">{postData.title}</h3>
             <div className="mb-1 text-muted">{postData.date}</div>
             <p className="card-text mb-auto">{postData.content}</p>
             <Link to="/postDetails" className="stretched-link">Continue reading</Link>
           </div>
           <div className="col-auto d-none d-lg-block">
             <svg className="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c" /><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>
           </div>
         </div>
       </div>
     )}
    </div>
  )
}

export default Post;