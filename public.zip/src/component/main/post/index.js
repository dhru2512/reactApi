import Post from "./post";

export default Post;