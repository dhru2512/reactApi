import Banner from "./banner";

export default Banner;