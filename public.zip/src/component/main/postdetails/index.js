import PostDetails from "./postdetails";

export default PostDetails;